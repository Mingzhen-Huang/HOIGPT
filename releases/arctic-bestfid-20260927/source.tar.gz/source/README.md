This directory is a reviewed candidate, not the code used by the running Stage 3 job.

The parent audit report describes all remaining differences from arXiv:2503.19157v1. In particular, original mixed ARCTIC+GRAB splits and the official evaluator are still missing; this candidate does not certify paper reproduction.

Validated changes:
- Span corruption operates on unpadded content, with a valid encoder attention mask.
- Structured token lengths become sampled frame counts and seconds in instruction prompts.
- Random half-window masks use a dedicated mask token; object-conditioned training preserves object codes and masks both hands.
- Prediction suffixes are appended after the known prefix before decoding.
- Explicit train shuffle also works at a single-GPU entry point. Existing Lightning DDP already shuffled the old experiment.
- Best-checkpoint filenames use the real epoch field, and predictions are saved under individual replication directories.

The CPU differential probe used the server's real tokenizer and a tiny T5. It checked finite supervised losses for all 9 candidate tasks, finite denoising backward, structured round-trip, exact prediction prefix alignment, duration labels, masking, and sentinel identity. It is not a full training or quality benchmark.

configs/config_hoi_audit_stage3.yaml selects the new HOI instruction file. The absolute TASK_PATH currently points to the isolated audit directory on erie. Do not launch the old config and assume it uses these templates.

Before starting a new LM run:
1. Freeze the new tokenizer's weights, EMA buffers, decoder implementation, normalization and temporal sampling.
2. Export a new complete token set and record the tokenizer SHA256, split IDs and token-file hashes.
3. Train Stage 2 with this exact token set and the corrected corruption implementation.
4. Initialize Stage 3 from that Stage 2 validation-best checkpoint, verifying the actual epoch, metric, codebook state and source hashes. Use fresh optimizer state for stage transition; full optimizer state only when resuming the same Stage 3 run.
5. Keep the requested 8 GPUs, explicitly record global batch and seeds, and use a separate named evaluation protocol with no duplicated IDs.
6. Complete the unresolved physical metrics and original data protocol before claiming agreement with the paper.

Do not plug newly trained codebooks into the currently running T5. Code IDs may have new meanings even when vocabulary sizes and tensor shapes match.
